#!/bin/bash
export PROJECT_ID="$1"
export REGION="$2"
export ZONE="$3"

echo "PROJECT_ID=${PROJECT_ID} REGION=${REGION} ZONE=${ZONE}"

# Set the Platform Project
gcloud config set project "${PROJECT_ID}"

# Create CloudBuild script
cat << 'EOF' > cloudbuild.yaml
steps:
- id: startup_script
  name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'
  env:
  - 'PROJECT_ID=${_PROJECT_ID}'
  - 'REGION=${_REGION}'
  - 'ZONE=${_ZONE}'
  script: |
    #!/bin/bash
    ## SCRIPT START
    gcloud services disable datafusion.googleapis.com --force
    sleep 3
    gcloud services enable datafusion.googleapis.com
    sleep 3
    gcloud beta data-fusion instances create --location="${REGION}" --zone="${ZONE}" cdf-lab-instance --enable_stackdriver_logging
    #CHECK=`gcloud beta data-fusion instances list --location=us-central1 | grep datafusion.googleusercontent.com | wc -l`
    #if [ $CHECK -eq 1 ]; then
    #  gcloud beta runtime-config configs variables set success/training-vm success --config-name training-vm-config; break;
    #fi
    ## SCRIPT END

timeout: 900s
substitutions:
  _PROJECT_ID: project_id
  _REGION: region
  _ZONE: zone
options:
  substitution_option: 'ALLOW_LOOSE'
EOF

#Initiate CloudBuild Trigger
gcloud builds submit --config=cloudbuild.yaml --project="${PROJECT_ID}" \
  --substitutions=_PROJECT_ID="${PROJECT_ID}",_REGION="${REGION}",_ZONE="${ZONE}"

